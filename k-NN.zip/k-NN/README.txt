The file named main.py is the source code that I wrote for k-NN algorithm. All files 
needed to operate the code are included in this folder.I use pyCharm to create the code. 
After opening the py file, you might have to install matplotlib before click to run. At 
line 205, I typed graph2() to create the graph over testing set. If you want to create 
a graph over training set, simply write graph1() and the graph will be created.

The performance of my model is shown in graphs.

Dataset Download: https://people.cs.umass.edu/~bsilva/courses/CMPSCI_589/Spring2022/homeworks/datasets/iris.csv