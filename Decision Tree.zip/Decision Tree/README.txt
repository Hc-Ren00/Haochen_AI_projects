The file named main.py in this folder is the source code that I wrote for Decision Tree algorithm.  
All files needed to operate the code are included in this folder.I use pyCharm to create the code. 
After opening the py file, you might have to install matplotlib before click to run. At
line 344 and 345, two graphs are created. The current code in the source code uses Gini
instead of information gain. However, it can easily switch between these two method as 
indicated at line 90-91. 

The performance is shown in graphs.

Dataset Download: https://people.cs.umass.edu/~bsilva/courses/CMPSCI_589/Spring2022/homeworks/datasets/house_votes_84.csv